/*
 * Copyright (c) 2006 Sun Microsystems, Inc.  All rights reserved.  U.S.
 * Government Rights - Commercial software.  Government users are subject
 * to the Sun Microsystems, Inc. standard license agreement and
 * applicable provisions of the FAR and its supplements.  Use is subject
 * to license terms.
 *
 * This distribution may include materials developed by third parties.
 * Sun, Sun Microsystems, the Sun logo, Java and J2EE are trademarks
 * or registered trademarks of Sun Microsystems, Inc. in the U.S. and
 * other countries.
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. Tous droits reserves.
 *
 * Droits du gouvernement americain, utilisateurs gouvernementaux - logiciel
 * commercial. Les utilisateurs gouvernementaux sont soumis au contrat de
 * licence standard de Sun Microsystems, Inc., ainsi qu'aux dispositions
 * en vigueur de la FAR (Federal Acquisition Regulations) et des
 * supplements a celles-ci.  Distribue par des licences qui en
 * restreignent l'utilisation.
 *
 * Cette distribution peut comprendre des composants developpes par des
 * tierces parties. Sun, Sun Microsystems, le logo Sun, Java et J2EE
 * sont des marques de fabrique ou des marques deposees de Sun
 * Microsystems, Inc. aux Etats-Unis et dans d'autres pays.
 */


package template;

import java.util.logging.*;


public final class Debug {
    static final Logger logger =
        Logger.getLogger("server.com.sun.cb.template.Debug");
    public static final boolean debuggingOn = true;

    public static void print(String msg) {
        if (debuggingOn) {
            logger.severe(msg);
        }
    }

    public static void println(String msg) {
        if (debuggingOn) {
            logger.severe(msg);
        }
    }

    public static void print(Exception e, String msg) {
        print((Throwable) e, msg);
    }

    public static void print(Exception e) {
        print(e, null);
    }

    public static void print(Throwable t, String msg) {
        if (debuggingOn) {
            logger.severe("Received throwable with Message: " + t.getMessage());

            if (msg != null) {
                logger.severe(msg);
            }

            t.printStackTrace();
        }
    }

    public static void print(Throwable t) {
        print(t, null);
    }
}
